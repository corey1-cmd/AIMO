# detnete — Deterministic Activity Scheduler

> A JavaScript scheduling engine that takes natural-language activity descriptions (Korean), infers dependencies from a 1373-activity taxonomy, and produces a time-anchored execution plan with hard guarantees on time monotonicity, energy accounting stability, and slack safety.

**Version**: 3.1.0
**Runtime**: Node 18+ (ES modules)
**Tests**: 90/90 passing
**External deps**: none

---

## Quick start

```bash
# Install
npm install    # no external deps; this just resolves package.json

# Run tests
npm test

# Demo
npm run demo
```

```javascript
import { analyze, replan } from './analyze-v3.js';

const result = analyze('샤워하고 아침 먹고 논문 쓰기', {
  now: '08:30',
  fixedEvents: [{ tag: 'regular_meeting', startAt: '10:00' }],
});

console.log(result.summary);
// [주 레이어]
//   08:30 1. full_shower               [12분 → 12분] ·E0 ×1.00
//   08:42 2. simple_meal               [12분 → 12.7분] ·E2 ×1.06
//   08:55 3. yogurt_granola            [3분 → 3.5분] ·E5.3 ×1.17
//        ──── 61.7분 여유 (고정 이벤트 대기) (08:58~) ────
//   10:00 4. regular_meeting           [45분 → 52.8분] ·E5.3 ×1.17 📌
//   10:53 5. full_draft                [360분 → 499.2분] ·E10.9 ×1.39
```

---

## File structure

### Core engine (5 modules)

| File | LOC | Role |
|---|---|---|
| `analyze-v3.js` | 151 | Public entry. Orchestrates parser → dependency-engine → scheduler. Exports `analyze()`, `replan()`, `filterExpiredAnchors()`. |
| `parser-v3.js` | 534 | Korean natural-language → L4 activity-tag list. L3/L4 reverse indices, SYNONYMS table, compound-sentence splitter, duration/modifier extraction. |
| `dependency-engine.js` | 555 | Dependency inference (P1–P10 rules), hard/soft edge graph, topological sort with tiebreakers, missing-activity inference, constraint checkers (P6, P7, P8, P9). |
| `dep-rules.js` | 272 | Declarative rule DSL. Each P-rule = data (id, principle, when, strength, refs). `inferDependencyTyped()`, `validateRules()`, `explainOrder()`. |
| `scheduler.js` | 718 | Single-pass walker. Layer separation (bg/main), anchor interleaving, energy accounting, passive-slot filling, slack gate, reserve slots. |

### Stabilization modules (added during the invariant-hardening work)

| File | LOC | Role |
|---|---|---|
| `time-contract.js` | 104 | `TimeContext` class, `TimeRegressionError`, `parseTime`, `nowContext`. Single source of truth for "now." |
| `interruption.js` | 138 | State machine for paused tasks. `makeInterrupted()`, `buildResumeItems()`, `interruptedEnergyContribution()`. |

### Data

| File | LOC | Role |
|---|---|---|
| `types-v3.js` | 57,912 | Frozen taxonomy: 22 L1 categories → 208 L2 → 609 L3 → 1373 L4 activities. Each L4 carries 13 attributes (act, pas, phy, cog, emo, bg, stk, int, sw, loc, mov, flex, timeBound). **Do not modify.** |

### Testing

| File | LOC | Role |
|---|---|---|
| `test-v3.js` | 1,070 | 90-test assertion harness. 16 groups covering parser, dep inference, topo sort, scheduler math, anchors, DSL, walker adversarial, Task1–4 stabilization, Problem1–3 invariant proofs. |

### Meta

| File | Role |
|---|---|
| `package.json` | Project metadata; declares `type: "module"` and test/demo scripts. |
| `README.md` | This file. |
| `PROJECT.md` | Progress journal, architectural decisions, invariants, known issues. |

---

## Public API

### `analyze(text, opts?) → Result`

Primary entry. Parses text, builds dependency graph, produces schedule.

**Parameters**:
```typescript
text: string                              // Korean natural-language input
opts: {
  // Time
  now?: string | number                   // "HH:MM" or absolute minutes. Authoritative.
  currentTime?: string                    // Legacy alias for `now`.
  timeCtx?: TimeContext                   // Pre-built context (highest precedence).

  // Constraints
  fixedEvents?: Array<{tag, startAt}>     // Hard anchors. startAt can be numeric for sub-minute precision.
  runningTask?: {id, endsAt}              // Currently-running task (affects Task2 anchor filter).
  interruptions?: Array<InterruptedTask>  // Paused tasks to resume/restart (Task 3).

  // Options
  inferMissing?: boolean                  // Default true. Auto-insert warmup, shower-after-sports, etc.
  optimize?: boolean                      // Default true. Reorder via topo sort.
  weights?: {L1:{}, L2:{}, L3:{}}         // Personalization multipliers on activity durations.
  companionState?: {active, type}         // P9 constraint (e.g., child present).
  currentHour?: number                    // P7 periodic triggers (brush teeth morning/night).
  recoveryThresholds?: {physical, cognitive, emotional}

  strictTimeEnforcement?: boolean         // Default true. Throws on H1 violation.
}
```

**Returns**:
```typescript
{
  input: string
  parsed: string[]                        // L4 tags recognized
  parsedDetails: Array<{input, l3, l4, baseAct, modifiers}>
  unmatched: string[]                     // Input fragments that didn't match
  inferred: Array<{tag, by, strength, position}>
  finalOrder: string[]
  dependencies: string[]                  // Human-readable edges
  constraints: {allowed, blocked, warnings}  // P9
  periodicSuggestions: Array<{tag, reason, priority}>  // P7
  emotionalWarnings: Array<{afterTag, affectedTag, msg, multiplierSuggestion}>  // P8
  recoverySuggestions: Array<{afterStep, reason, suggested, type}>  // P6
  schedule: {
    timeline: Array<Step>                 // Including idle gaps and reserve slots
    totalActive, totalPassive, totalElapsed, finalEnergy
    savedTime                             // Time saved by passive-slot filling
    energyTrace                           // Cumulative energy at each step
    droppedAnchors: Array<{tag, reason, ...}>  // Anchors rejected at validation
    backgroundLayer                       // Items running in parallel (e.g., music)
  }
  summary: string                         // Human-readable formatted output
  ctx: TimeContext                        // For subsequent replan() calls
}
```

### `replan(prevResult, newNow, optsDelta?) → Result`

Re-runs `analyze` with monotonically-advanced `now`.

Throws `TimeRegressionError` if `newNow < prevResult.ctx.now`.
Throws `TimeRegressionError` if `prevResult.ctx` is missing.

### `filterExpiredAnchors(anchors, ctx, {runningTask?}) → {kept, dropped}`

Pre-scheduler filter. Categorizes each anchor:
- `STRICT_PAST` — `fixedAt < ctx.now`
- `OVERLAPPED_BY_RUNNING` — running task still active at fixedAt
- `COLLAPSED_AFTER_DELAY` — same-minute duplicate

### `TimeContext({now, epoch?, source?})`

Frozen value object. `advance({now})` returns a new context with `epoch + 1`; throws if `now` regresses.

### `TimeRegressionError`

Thrown on any invariant violation. `err.kind ∈ {INVALID_NOW, NOW_WENT_BACKWARD, H1_VIOLATION, H2_VIOLATION, H3_VIOLATION, INVALID_TIME_FORMAT, REPLAN_REQUIRES_CTX, INTERRUPT_INVALID_TIMES, INTERRUPT_NEGATIVE_ELAPSED, INTERRUPT_INVALID_MODE}`.

---

## Hard invariants (checked at runtime when `strictTimeEnforcement: true`)

| ID | Statement | Enforcement site |
|---|---|---|
| **H1** | `∀ step ∈ timeline: step.startTime ≥ ctx.now` | `ctx.assertFuture(clock)` at every emission |
| **H2** | timeline is monotonically non-decreasing | `ctx.assertMonotonic(prevEnd, step)` at every emission |
| **H3** | no placed anchor has `fixedAt < ctx.now` | pre-filter in `filterExpiredAnchors` + scheduler-internal check |
| **H4** | `ctx.now` is monotonically non-decreasing across `replan()` calls | `TimeContext.advance()` |
| **H5** | `∀ admitted step s: s.startTime + s.actFinal ≤ nextAnchor.fixedAt + EPS` | `slackGate()` dual-layer rule |

### Numerical constants

```javascript
CONFIG = {
  ENERGY_K: 0.03,                 // Exponential energy → multiplier coefficient
  BG_ENERGY_FACTOR: 0.3,          // Background activities contribute 30% to main
  RECOVERY_FACTOR: -0.5,          // Recovery = negative half-weight
  CROSS_FATIGUE_K: 0.3,           // Multi-channel simultaneous cost
  MAX_ENERGY_CAP: 25,             // Symmetric cap on cumulative energy
  PER_ACTIVITY_MULT_CAP: 1.5,     // No activity can stretch > 1.5× base
  SLACK_SAFETY_MARGIN: 0.8,       // effective_slack = slack × 0.8
  SLACK_NUMERIC_EPS: 0.1,         // Float-tolerance ONLY, not a capacity buffer
  SLACK_RESERVE_THRESHOLD: 0.5,   // Slack below this → inert reserve slot
}
```

---

## Architecture (pipeline view)

```
user text (Korean)
   │
   ▼
parser-v3.js ── L4 tags + per-fragment details ──┐
                                                  │
                                                  ▼
dependency-engine.js
   │ inferMissingActivities   (P1..P10)
   │ buildDepGraphTyped       (hard/soft edge separation)
   │ topoSortWithTiebreak     (no silent drops; cycles broken explicitly)
   │ checkCompanionConstraint (P9 — informational)
   │ checkPeriodicTriggers    (P7 — informational)
   │ checkEmotionalCarryover  (P8 — wired to scheduler)
   │ suggestRecovery          (P6 — informational)
   │
   ▼
time-contract.js ── resolve TimeContext, enforce H1..H4 ─┐
                                                          │
analyze-v3.js                                             │
   │ filterExpiredAnchors (Task2: STRICT_PAST, OVERLAPPED_BY_RUNNING, COLLAPSED)
   │ build p8Map from emotionalWarnings                   │
   │                                                      │
   ▼                                                      │
scheduler.js  (single-pass walker)                        │
   │ Phase I : materialize items                          │
   │ Phase II: layer split (bg items run in parallel)     │
   │ Phase III: anchor validation                         │
   │ Phase IV: walker loop                                │
   │   each iter: snapshot → evaluateCandidate (pure)     │
   │              → slackGate (dual-layer rule)           │
   │              → admit / reserve / defer / anchor-fire │
   │   passive slot: 2-phase (plan against snapshot, commit in order)
   │   H1 enforced at every emission                      │
   ▼
Result { timeline, summary, ctx, droppedAnchors, ... }
```

---

## Failure-mode behavior

| Input anomaly | Behavior |
|---|---|
| Unrecognized Korean phrase | `unmatched[]` populated, `error` if nothing matched |
| Cycle in hard dependencies | Cycle broken by dropping one hard edge, `cycleDetected.nodes` populated |
| Anchor with `fixedAt < now` | Dropped with `reason: 'STRICT_PAST'` |
| Anchor for unknown L4 tag | Dropped with `reason: 'UNKNOWN_TAG'` |
| Two anchors at same minute | Second dropped with `reason: 'COLLAPSED_AFTER_DELAY'` |
| Flex too big to fit before anchor | Deferred; anchor fires; `slackRejection` metadata on anchor step |
| Slack in (0, 0.5] minutes | Inert reserve slot emitted instead of idle gap |
| `replan()` with earlier `now` | `TimeRegressionError[NOW_WENT_BACKWARD]` thrown |
| `replan()` without prev context | `TimeRegressionError[REPLAN_REQUIRES_CTX]` thrown |
| Interrupted task with negative elapsed | `TimeRegressionError[INTERRUPT_NEGATIVE_ELAPSED]` thrown |
| Interrupted task ran over original | Elapsed clamped; `remaining = 0` |

---

## Determinism guarantees

- Identical input → identical output (verified by idempotence test)
- Candidate evaluation is pure; no state-dependent ordering bias
- Passive-slot filling is two-phase (plan against snapshot, commit in selection order)
- `flexQueue` ordering is stable across runs

---

## Known limitations

1. **Taxonomy is Korean-only.** Parser has no abstraction layer for other languages.
2. **Energy model is a closed-form guess.** `exp(0.03 × cumE)` and the 1.5× cap are empirical.
3. **No optimization objective.** The scheduler produces *a* feasible schedule, not the best one. Adding optimization would require CP-SAT or similar.
4. **No windows or separations yet.** Anchors are point constraints only. Design proposal for STN-based extension exists in `PROJECT.md`.
5. **1.2 MB `types-v3.js` is loaded eagerly.** Lazy loading by L1 is a deferred refactor.
6. **Synthetic tags (`nearby_store__return`) bypass `getL4()`.** Works but violates namespace closure.

---

## Development

```bash
# Run all tests
node --max-old-space-size=256 test-v3.js

# Expected: "90 passed, 0 failed"

# Run a single group (grep-based)
node test-v3.js 2>&1 | grep "^[✓✗].*Task4"
```

See `PROJECT.md` for detailed progress log and architectural decisions.
