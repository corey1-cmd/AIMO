# detnete — Project Progress & Implementation Journal

This document is the engineering record of how the scheduler reached its current state. It is meant for the next engineer (human or AI) picking up the work: what was done, what was decided, why, and what remains.

---

## Starting state (baseline)

The initial handoff provided:

- A 1373-entry L4 activity taxonomy (`types-v3.js`, frozen).
- 10 dependency principles P1–P10 described informally in `dependency-principles.md`.
- A parser, dependency engine, and scheduler totaling ~1500 LOC.
- A test matrix in `PROJECT-HANDOFF.md` claiming full coverage with self-reported ✅ marks.
- One smoke test in `package.json` that called `console.log` once.

The baseline claim was "prototype works on 3–5 activity inputs." The actual state, determined by building a proper test harness:

- **11 of 27 invariants failed** on realistic input.
- Key documented features (P8 ×1.2 multiplier, anchor semantics) were not actually wired through to the scheduler.
- The topological sort silently dropped items on cycles, producing schedules missing ~60% of the user's input.
- Reported elapsed time was wrong by 7+ hours (absolute clock vs. duration confusion).

---

## Session-by-session delivery log

### Session 1 — MVP bug fixes (baseline → 32 tests passing)

Focus: find and fix the bugs the self-reported test matrix missed.

**Bugs fixed:**

| ID | Issue | Fix location |
|---|---|---|
| A | Topo sort silently drops items on cycle | `dependency-engine.js`: split hard/soft edges, `topoSortWithTiebreak` emits all items, cycle breaker records `dropped[]` |
| B | `totalElapsed` reports absolute clock, not duration | `scheduler.js`: `round1(clock - clockStart)` |
| C | Past anchors silently misplaced | `scheduler.js`: reject with `droppedAnchors[].reason = 'PAST_ANCHOR'` |
| D | Anchor interleaver uses raw base time, not energy-adjusted | `scheduler.js`: track `simEnergy` through interleaver |
| E | All P4 travel inference falls back to `nearby_store` regardless of destination | `dependency-engine.js`: `pickTravelL4For(dest)` / `pickReturnL4For(dest)` L1-aware mapping |
| F | Invalid SYNONYMS targets silently drop tags (`코딩` → `coding_dev` which was L2, not L3/L4) | `parser-v3.js`: L2-code fallback in `matchL3`; `getSynonymHealth()` export; `DETNETE_STRICT=1` mode |
| H | P8 emotional multiplier never applied to schedule despite being computed | `analyze-v3.js` + `scheduler.js`: threaded `emotionalAdjustments: Map<tag, multiplier>` through, applied as `actFinal *= p8Mult` |
| I | Cross-fatigue compounds with recovery (recovery + multi-channel → large negative energy) | `scheduler.js`: recovery activities bypass cross-fatigue entirely |
| K | Per-activity multiplier is unbounded (360min task could stretch to 500+min) | `scheduler.js`: `PER_ACTIVITY_MULT_CAP = 1.5` |

**Parser fixes:**
- "하고밥먹기" (no space between verbs) didn't split correctly → tightened `verbGo` regex with lookahead
- "밥먹기" (space removed from synonym) didn't match `밥 먹` → added `SYNONYMS_NOSPACE_SORTED` secondary index

**Files added:** `test-v3.js` (assertion harness, 32 tests).

**Outcome:** 32/32 tests passing. Every bug from the review has at least one regression test.

---

### Session 2 — Rule DSL refactor (32 → 32 tests, architectural)

Focus: replace the chain of string-literal `l1/l2/l3` checks in `inferDependency` with a data-driven DSL.

**Before**: 40+ lines of if-chain, fragile to taxonomy renames, no way to introspect why a rule fired, no way to validate references exist.

**After**: `dep-rules.js` with 19 rules across P1–P10, each declared as data:

```javascript
{
  id: 'P1.prep-before-eat',
  principle: 'P1',
  when: (a, b) => a.l2 === 'food_prep' && b.l1 === 'eating',
  strength: 'hard',
  description: '음식 준비는 식사 전에',
  refs: { l2: ['food_prep'], l1: ['eating'] },  // validated at load
}
```

**Benefits:**
- `validateRules()` checks every rule's `refs` at module load; taxonomy rename fails fast.
- `explainOrder(a, b)` returns human-readable trace: `"standard_meal → yogurt_granola [P1.prep-before-eat P1: 음식 준비는 식사 전에]"`
- Hard/soft edge classification now flows from rule.strength, not hardcoded in engine logic.
- `dependency-engine.js` shrank; `inferDependency` is now a 3-line delegator.

**Also deleted:** `splitLayers()` (exported but unused), `splitLayersFromItems()` (internal duplicate).

---

### Session 3 — Single-pass walker (32 → 42 tests)

Focus: eliminate the dual-phase scheduler (interleaver + main loop) that was the root cause of Bug D's class.

**Problem**: Old scheduler had Phase 0 (anchor interleaver) making placement decisions using one `simEnergy` counter, then Phase 1 (main loop) running with a separate `cumulativeEnergy`. The two drifted. Any patch to the estimate (like Bug D's fix) was papering over the architectural split.

**Solution**: Fold both phases into one walker maintaining `(clock, cumulativeEnergy, pendingAnchors)` as single source of truth. Four explicit cases in the main loop:

```
Case A: anchor due or overdue → fire now
Case B: anchor in future, flex available → admission control
Case C: only anchor left → jump clock, fire
Case D: nothing left → halt
```

**Added**: 5 adversarial walker tests (anchor-at-currentTime, flex-doesn't-fit, timeline-continuity, past+future-anchor mixing, empty-droppedAnchors shape).

**Also found and fixed**: same-tag anchor twice collapsing into one emission → added `_id` to each PendingAnchor.

---

### Session 4 — Stabilization (42 → 66 tests)

This session introduced three new concerns: time-monotonicity enforcement, expired-anchor filtering, and interruption handling. Each got its own module.

#### Task 1 — Time monotonicity

**New module**: `time-contract.js` with `TimeContext`, `TimeRegressionError`, `parseTime`.

**Key idea**: one source of truth for "now." The scheduler no longer derives "now" from `opts.currentTime` ad-hoc; callers build a `TimeContext`, which is frozen, carries a monotonic `epoch`, and rejects regressions via `advance()`.

**Enforcement sites (H1):**
1. Entry-time clamp: `clock = max(clockStart, ctx.now)`
2. Per-emission `ctx.assertFuture(clock)`
3. Per-emission `ctx.assertMonotonic(prevEnd, step)`

**Replan support**: `analyze-v3.js` exports `replan(prevResult, newNow)` which calls `prevResult.ctx.advance({now: newNow})`. Throws `TimeRegressionError[NOW_WENT_BACKWARD]` on violation.

**Failure paths identified (FP-1..FP-6):**
- FP-1: caller passes stale `currentTime` after network round-trip → fixed by `TimeContext` being authoritative
- FP-2: replan uses original `clockStart` → fixed by `replan()` forcing new `ctx`
- FP-3: past anchor silently placed → already fixed (Bug C), strengthened with `ctx.now` threshold
- FP-4: interrupted task reinserted at original position → fixed by Task 3
- FP-5: STN mode would produce feasible past schedule → documented for future work (β proposal)
- FP-6: relative-time mode permissive by default → made opt-in

**Tests added**: 9 assertions (H1 clamp, H4 regression, epoch advance, replan-without-ctx, etc.)

#### Task 2 — Expired anchor handling

**New export**: `filterExpiredAnchors(anchors, ctx, {runningTask?})` in `analyze-v3.js`.

Categorizes each anchor:
- `STRICT_PAST` — `fixedAt < ctx.now`
- `OVERLAPPED_BY_RUNNING` — running task will still be active at `fixedAt`
- `COLLAPSED_AFTER_DELAY` — same-minute duplicate

Runs **pre-scheduler**, so the dependency engine never sees expired anchors. Merged with scheduler-internal `droppedAnchors` in the final result.

**Tests added**: 4 assertions covering all three categories plus null-ctx backward compat.

#### Task 3 — Interruption handling

**New module**: `interruption.js`.

State machine:
```
Scheduled → Running → Paused → {Resumed | Restarted | Abandoned} → Completed
```

Data model:
```typescript
InterruptedTask = {
  itemId, originalAct, elapsed, remaining,
  resumeMode: 'resume' | 'restart' | 'abandon',
  pausedAt, startedAt, state,
  energyFraction,  // for resume: fraction already contributed
}
```

Invariants:
- `INT-1`: `remaining ≥ 0`
- `INT-2`: `pausedAt ≥ startedAt`
- `INT-3`: resumed task placed in timeline has `startTime ≥ ctx.now` (inherits H1)
- `INT-4`: on resume, energy contributes `(1 - elapsed/originalAct)` fraction
- `INT-5`: on restart, full originalAct contribution
- `INT-6`: abandoned tasks not in timeline

**Integration**: `buildResumeItems()` produces scheduler-ready items prepended to flex queue. Energy accounting uses `interruptedEnergyContribution()` in place of normal `energyContribution()` for items with `_interrupted` metadata.

**Tests added**: 11 assertions covering resume/restart/abandon, elapsed clamping, energy-fraction math, H1 compliance, dedup against parsed input.

---

### Session 5 — Task 4 slack-based control (66 → 76 tests)

**Problem (spec)**: An "energy → duration↑ → anchor violation → reorder → recompute" feedback loop.

**Honest engineering note**: This loop did not exist in the current single-pass walker (Session 3 eliminated it structurally). Task 4 is therefore a belt-and-suspenders pre-admission check, not a bug fix. The spec's "no iterative convergence" constraint is satisfied trivially because the walker never iterates.

**What shipped**: `canEmitFlex()` (later renamed `slackGate()` in Session 6) as a pure pre-emission check at each flex decision point.

Admission rule:
```
predTotal = predActive + predPassive     // includes passive, per spec
slack = nextAnchor.fixedMin - clock
effectiveSlack = slack × SAFETY_MARGIN   // = slack × 0.8
admit ⟺ predTotal ≤ effectiveSlack
```

On rejection: emit idle gap, fire anchor, record `slackRejection` metadata on the anchor step for observability.

Policy for "no task fits": `JUMP_TO_ANCHOR` (idle + anchor). Deferred flex stays at `flexIdx` and retries against the next anchor.

**Config**: `SLACK_SAFETY_MARGIN: 0.8`, `SLACK_NEAR_ZERO_EPS: 0.5` (both added to `CONFIG`).

**Tests added**: 10 assertions (admit boundary, safety margin, passive inclusion, near-zero, multi-anchor, deferred-not-dropped, large-task-defer, no-anchor-path, relative-time bypass).

---

### Session 6 — Stabilization refactor (76 → 90 tests)

Focus: address three structural-instability concerns surfaced in the stabilization brief.

#### Problem 1 — Time regression (clock normalization)

**Change**: introduced `effClock() = ctx ? max(clock, ctx.now) : clock`. Every decision site (Case A anchor-due, Case C jump-to-anchor, slack gate, idle-gap start) reads through it.

**Rationale**: raw `clock` is still used as a commit target inside emission functions, but any comparison that feeds a scheduling decision goes through `effClock()`. This makes it structurally impossible for a stale clock to inflate slack or fire an anchor early — the normalization is a read-side guarantee.

#### Problem 2 — Energy snapshot stability

**Change**: split candidate evaluation from commit.

- `snapshot()` captures `(energy, clock)` frozen.
- `evaluateCandidate(cand, snap)` is pure — no mutation of `cumulativeEnergy` or `clock`.
- Passive-slot inner loop now two-phase:
  - **PHASE 1** (PURE): walk candidates against `baseEnergyForSlot` and `simEnergyForPlanning` local vars, build `chosen[]`
  - **PHASE 2** (COMMIT): emit `chosen[]` in selection order, updating real state

**Metadata**: `passiveSlot.baseEnergySnapshot` and `baseClockSnapshot` exposed for traceability.

**Proof**: determinism test verifies identical inputs produce bit-identical `finalEnergy` and `totalActive`.

#### Problem 3 — Slack + near-zero

**Change**: config split, discriminated-union gate result, reserve-slot semantics.

Config:
- `SLACK_NUMERIC_EPS = 0.1` — float-tolerance ONLY (range `[0.05, 0.2]`)
- `SLACK_RESERVE_THRESHOLD = 0.5` — structural near-zero boundary

Gate:
```javascript
slackGate(eval, anchor, snap) → {
  kind: 'UNCONSTRAINED' | 'ADMIT' | 'REJECT_NEAR_ZERO' | 'REJECT_EXCEEDS',
  predTotal, slack, effectiveSlack
}
```

Dual-layer rule: `admit ⟺ predTotal ≤ effectiveSlack + SLACK_NUMERIC_EPS`.

Reserve slot (`emitReserveSlot`): inert marker with `{type: 'padding', energy: 0, decisionWeight: 0, visibleOnly: true, actFinal: 0, pasFinal: 0, isReserve: true, reserveReason}`. Emitted when `slack ≤ RESERVE_THRESHOLD`. Not a task, not an optimization variable, advances `clock` but contributes nothing to energy.

**Side-effect bug caught**: `formatSchedule` assumed every non-gap step had `energyMultiplier`. Reserve slots don't. Added reserve-rendering branch and `?.toFixed(2) ?? '—'` fallback. Regression test added.

**Tests added**: 13 assertions covering P1 (effClock), P2 (determinism), P3 (EPS boundary, reserve path exercised via fractional `startAt`, reserve shape, clock monotonicity through reserve).

---

## Final state

**Test count**: 90/90 passing, idempotent across consecutive runs.

**Invariants verified empirically** (direct `node -e` invariant checks outside test harness):
- H1: `∀ step: step.startTime ≥ ctx.now` ✓
- H2: timeline monotonically non-decreasing ✓
- H3: no past anchor placed ✓
- H4: `replan(earlier)` throws ✓
- H5: slack-rejection surfaces on anchor steps ✓
- Determinism: two identical runs → bit-identical schedule ✓

**Files** (9 source + 1 test, 3,542 total LOC excluding `types-v3.js`):
```
analyze-v3.js       151 LOC   Public entry + replan + expired-anchor filter
parser-v3.js        534 LOC   Korean NL → L4 tags
dependency-engine.js 555 LOC  P1-P10 inference + hard/soft graph + topo sort
dep-rules.js        272 LOC   Declarative rule DSL
scheduler.js        718 LOC   Single-pass walker + slack gate + reserve slots
time-contract.js    104 LOC   TimeContext / TimeRegressionError
interruption.js     138 LOC   State machine + resume/restart semantics
test-v3.js         1070 LOC   90 assertions across 16 groups
types-v3.js       57912 LOC   Frozen taxonomy (1373 L4 activities)
```

---

## Architectural decisions worth preserving

1. **Hard/soft edge separation in dependency graph**: hard edges (P-rules) are mandatory topological constraints; soft edges (user input order) are tiebreakers only. Cycle detection runs on hard edges. This eliminates Bug A's entire class.

2. **Single-pass walker over two-phase scheduler**: having one `(clock, cumulativeEnergy)` pair makes Bug D unpatchable-but-structurally-absent. Any future temporal model (e.g., STN) should preserve this property.

3. **Rule DSL over string-literal if-chains**: the `DEP_RULES` array makes P1-P10 introspectable (`explainOrder`), validatable (`validateRules()`), and strength-classified. Adding a new P-rule is one data entry, no engine changes.

4. **TimeContext as value object**: frozen, immutable, monotonic epoch. `replan()` is the only way to advance. This prevents ad-hoc mutation and makes time-regression detection trivial.

5. **`effClock()` read-side guarantee**: `clock` still mutates normally on emission, but all *decisions* read through `max(clock, ctx.now)`. Keeps the emission path simple while making decisions structurally safe.

6. **Pure `evaluateCandidate` + discriminated-union `slackGate`**: evaluation is a function, not a procedure. Selection is deterministic. Side effects (clock advance, energy accumulation) happen in the commit step only.

7. **Reserve slot as inert first-class marker**: near-zero slack doesn't force a fit and doesn't silently idle. It emits a structurally-visible `isReserve: true` slot that downstream consumers (UI, metrics) can render distinctly.

8. **Interruption as modeled state machine, not boolean flag**: resume/restart/abandon are distinct modes with distinct energy semantics. `makeInterrupted()` is a factory with precondition checks (`INT-1`, `INT-2`).

---

## Known limitations (honest)

1. **Taxonomy is Korean-only.** The parser has no abstraction layer. Internationalization would require re-doing the SYNONYMS table per language and generalizing the normalization regex.

2. **Energy model is empirical.** `exp(0.03 × cumE)` and `PER_ACTIVITY_MULT_CAP = 1.5` are guesses calibrated against ~20 test scenarios. A principled fatigue model (e.g., two-process sleep model, Monod-kinetics for attention) would fit here.

3. **No optimization, only feasibility.** The walker produces *a* feasible schedule, not the best one. The next real feature would be CP-SAT-backed optimization (see `README.md` references to the β proposal).

4. **Windows and separations not expressible.** Anchors are point constraints only. "Eat between 18:00 and 20:00" or "take pill within 30 min of meal" can't be stated. STN proposal addresses this.

5. **Synthetic tags bypass `getL4()`.** `nearby_store__return` exists only as a transient object in the dependency engine. If any code round-trips through `getL4(tag)` the `_isReturn` flag is lost. Low-priority cleanup.

6. **`types-v3.js` is 1.2 MB loaded eagerly.** Lazy loading by L1 is a deferred refactor. For Lambda cold starts this adds 50-200 ms.

7. **`fillPassive` greedy algorithm is not optimal.** Two-phase evaluation is deterministic, but "fit as many as possible" is NP-hard in general (knapsack). Current heuristic: input order. Good enough for n<10 candidates.

8. **`slackGate` uses only NEAREST anchor.** A distant tight anchor might still be violated if closer anchors admit items. No global feasibility check; relies on per-decision locality.

---

## Where to pick up next

Priority 1 — **extend fixedEvents with tolerance windows**:
```javascript
fixedEvents: [{
  tag: 'regular_meeting',
  startAt: '10:00',
  toleranceWindow: [-5, 15]  // fires anywhere in [09:55, 10:15]
}]
```
STN natively supports this as an interval edge `Z → start_i [window_lo, window_hi]`. With the rule DSL already in place, this is ~50 LOC in `time-contract.js` + ~30 LOC in `scheduler.js`.

Priority 2 — **STN-based feasibility check as preflight**:
Run a pure constraint-consistency pass before the walker. On UNSAT, return structured conflict explanation (which edges would need to relax). This catches "your 10:00 meeting is infeasible given your 09:30 therapy + 30min travel" BEFORE emitting a doomed timeline.

Priority 3 — **P9/P6 output wiring**:
`checkCompanionConstraint` still produces `blocked[]` but the scheduler emits blocked items anyway. `suggestRecovery` produces suggestions that vanish. Both should either be injected into the timeline as inferred activities, or surface as hard errors.

Priority 4 — **Namespace closure for synthetic tags**:
Promote `direction: 'outbound' | 'return'` to a first-class field. Remove the `__return` suffix hack.

Priority 5 — **Lazy taxonomy loading**:
Split `types-v3.js` into per-L1 shards, lazy-load based on L1s seen in parse output.

---

## Proof-style summary of why the system is currently stable

**Time cannot regress**: every slack/anchor comparison reads `effClock() ≥ ctx.now`. `clock` mutates only forward inside emission functions. `ctx.assertFuture(clock, ...)` fires synchronously at every emission, catching any path that bypasses `effClock()` — so even refactor-induced bugs throw rather than silently produce past schedules.

**Energy cannot oscillate by ordering**: `evaluateCandidate` is pure (reads snapshot, not state). Passive-slot is two-phase (plan against snapshot → commit in selection order). `flexQueue` ordering is stable (built once at analyze-time). Therefore same input → same chosen set → same commit sequence → same timeline.

**Slack cannot inflate incorrectly**: `slack = anchor.fixedMin - snap.clock` where `snap.clock = effClock() ≥ ctx.now`. EPS is additive to `effectiveSlack = slack × 0.8`, giving ceiling `slack × 0.8 + 0.1 ≤ slack × 0.81`. Near-zero slack takes the reserve path unconditionally, bypassing admission.

These three properties are checked in the test suite as direct invariant assertions, not just behavioral tests. `node --max-old-space-size=256 test-v3.js` on a clean checkout should report `90 passed, 0 failed`.
