/* ═══════════════════════════════════════════════════════════════
   test-v3.js — minimal assertive test harness (ESM)

   Run with: node test-v3.js
   Exit code: 0 = all pass, 1 = any fail
   ═══════════════════════════════════════════════════════════════ */

import { analyze } from './analyze-v3.js';
import { parseInput } from './parser-v3.js';
import {
  inferDependency, inferMissingActivities, buildDepGraph,
  analyzeDependencies, checkEmotionalCarryover,
} from './dependency-engine.js';
import {
  schedule, computeAdjustedTime, energyContribution, energyMultiplier,
} from './scheduler.js';
import { L4_DB, L3_META, getL4 } from './types-v3.js';

const SYNONYMS_EXPECTED_VALID = true; // flip to skip if baseline failing

let passed = 0, failed = 0;
const failures = [];

function t(name, fn) {
  try {
    fn();
    passed++;
    process.stdout.write(`✓ ${name}\n`);
  } catch (e) {
    failed++;
    failures.push({ name, error: e.message, stack: e.stack });
    process.stdout.write(`✗ ${name}\n    ${e.message}\n`);
  }
}

function assert(cond, msg) {
  if (!cond) throw new Error(msg || 'assertion failed');
}
function assertEq(actual, expected, msg) {
  if (actual !== expected) {
    throw new Error(`${msg || 'eq'}: expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
  }
}
function assertDeepEq(a, b, msg) {
  if (JSON.stringify(a) !== JSON.stringify(b)) {
    throw new Error(`${msg || 'deepEq'}: expected ${JSON.stringify(b)}, got ${JSON.stringify(a)}`);
  }
}
function assertIncludes(arr, item, msg) {
  if (!arr.includes(item)) throw new Error(`${msg || 'includes'}: ${JSON.stringify(arr)} missing ${item}`);
}

/* ─── GROUP 1: Parser ─────────────────────────────────── */
t('parser: simple single activity', () => {
  const r = parseInput('샤워');
  assertEq(r.tags.length, 1);
  assertEq(r.tags[0], 'full_shower');
});

t('parser: compound with 고-separator', () => {
  const r = parseInput('샤워하고 밥먹기');
  assert(r.tags.length >= 2, `expected ≥2 tags, got ${r.tags.length}`);
});

t('parser: eleven activities all recognized', () => {
  const input = '요리하고 저녁먹고 설거지하고 샤워하고 빨래하고 논문쓰고 운동하고 책읽고 명상하고 양치하고 출근하고';
  const r = parseInput(input);
  assertEq(r.tags.length, 11, `parser dropped activities: got ${r.tags.length}`);
});

t('parser: duration extraction', () => {
  const r = parseInput('독서 30분');
  assert(r.tags.length === 1);
  assert(r.details[0].userDuration === 30, `duration not extracted: ${r.details[0].userDuration}`);
});

t('parser: unmatched input', () => {
  const r = parseInput('완전히 모르는 외계어');
  assertEq(r.tags.length, 0);
  assert(r.unmatched.length > 0);
});

/* ─── GROUP 2: Synonym integrity ──────────────────────── */
t('integrity: SYNONYMS targets exist (L3 or L4)', () => {
  // We can't import SYNONYMS directly, so validate via parser behavior
  // Quick sample check — not exhaustive
  const samples = ['샤워', '요리', '논문 쓰기', '운동', '아침', '저녁', '코딩', '논문'];
  for (const s of samples) {
    const r = parseInput(s);
    assert(r.tags.length > 0, `synonym "${s}" produced no L4 tag`);
    const l4 = getL4(r.tags[0]);
    assert(l4, `synonym "${s}" → "${r.tags[0]}" not in L4_DB`);
  }
});

/* ─── GROUP 3: Dependency inference (pairwise) ────────── */
t('dep: food_prep before eating (P1)', () => {
  const a = getL4('standard_meal'); // food_prep
  const b = getL4('yogurt_granola'); // eating
  assertEq(inferDependency(a, b), 'before');
  assertEq(inferDependency(b, a), 'after');
});

t('dep: sports before shower (P3)', () => {
  const a = getL4('deadlift_session');
  const b = getL4('full_shower');
  assertEq(inferDependency(a, b), 'before');
});

t('dep: washing_machine before drying (P10)', () => {
  const a = getL4('delicate_cycle');
  const b = getL4('dryer_machine');
  assertEq(inferDependency(a, b), 'before');
});

t('dep: no relation between unrelated activities', () => {
  const a = getL4('novel_reading') || getL4('long_session');
  const b = getL4('morning_coffee');
  if (a && b) {
    const r = inferDependency(a, b);
    // Either none, or whatever — just shouldn't crash
    assert(['before','after','none'].includes(r));
  }
});

/* ─── GROUP 4: Missing activity inference ─────────────── */
t('infer: P1 adds cooking before home dinner', () => {
  const items = [getL4('yogurt_granola')].filter(Boolean);
  const inferred = inferMissingActivities(items);
  assert(inferred.some(i => i.l2 === 'food_prep'), 'expected food_prep inferred');
});

t('infer: P5 adds warmup before gym', () => {
  const items = [getL4('deadlift_session')].filter(Boolean);
  const inferred = inferMissingActivities(items);
  assert(inferred.some(i => i._inferredBy?.includes('웜업')), 'warmup not inferred');
});

t('infer: P3 adds shower after sports', () => {
  const items = [getL4('deadlift_session')].filter(Boolean);
  const inferred = inferMissingActivities(items);
  assert(inferred.some(i => i.l3 === 'shower'), 'shower not inferred');
});

/* ─── GROUP 5: Topological sort integrity ─────────────── */
t('order: no items lost on small input', () => {
  const r = analyze('샤워하고 아침먹고 출근');
  assert(r.finalOrder.length >= 3, `lost items: ${r.finalOrder.length}`);
  assert(r.parsed.every(p => r.finalOrder.includes(p)), 'parsed not subset of finalOrder');
});

t('BUG-A: 11 activities preserved through ordering (no cycle drop)', () => {
  const input = '요리하고 저녁먹고 설거지하고 샤워하고 빨래하고 논문쓰고 운동하고 책읽고 명상하고 양치하고 출근하고';
  const r = analyze(input);
  assert(r.parsed.length === 11, `parser regression: ${r.parsed.length}`);
  // Critical: every parsed tag must appear in finalOrder
  for (const tag of r.parsed) {
    assertIncludes(r.finalOrder, tag, `BUG-A: tag "${tag}" dropped during ordering`);
  }
  // Cycle should be reported if detected (not silent)
  if (r.cycleDetected) {
    assert(r.cycleDetected.nodes && r.cycleDetected.nodes.length > 0, 'cycleDetected has no details');
  }
});

t('order: P-rule beats user input order on conflict', () => {
  // User says "먹고 요리" (eat then cook) — P1 should reverse it
  const r = analyze('저녁먹고 요리');
  const eatIdx = r.finalOrder.findIndex(t => getL4(t)?.l1 === 'eating');
  const cookIdx = r.finalOrder.findIndex(t => getL4(t)?.l2 === 'food_prep');
  assert(cookIdx >= 0 && eatIdx >= 0, 'eat/cook not both present');
  assert(cookIdx < eatIdx, `cooking should precede eating: cook@${cookIdx}, eat@${eatIdx}`);
});

/* ─── GROUP 6: Scheduler time math ─────────────────────── */
t('sched: totalElapsed is duration, not absolute clock', () => {
  const r = analyze('샤워', { currentTime: '07:00' });
  // full_shower is 12 min, no inferred activities → elapsed should be ~12
  assert(r.schedule.totalElapsed < 60,
    `BUG-B: totalElapsed=${r.schedule.totalElapsed} looks like absolute clock (should be ~12 for a 12-min activity)`);
});

t('sched: clockTime renders correctly', () => {
  const r = analyze('샤워', { currentTime: '07:00' });
  assertEq(r.schedule.timeline[0].clockTime, '07:00');
});

t('sched: energy multiplier monotonically increases with cumulative', () => {
  const m1 = energyMultiplier(0);
  const m2 = energyMultiplier(5);
  const m3 = energyMultiplier(15);
  assert(m1 === 1.0, `m1=${m1}`);
  assert(m2 > m1 && m3 > m2, 'multiplier should be monotonic');
});

t('sched: recovery + cross-fatigue do not compound', () => {
  // Recovery activities with multiple channels should not get inflated by cross-fatigue then negated
  const meditation = getL4('guided_meditation') || getL4('long_guided');
  if (meditation && (meditation.phy > 0 || meditation.cog > 0 || meditation.emo > 0)) {
    const e = energyContribution(meditation);
    // For recovery, |e| should be ≤ 0.5 × raw sum (no cross-fatigue inflation)
    const rawSum = meditation.phy + meditation.cog + meditation.emo;
    assert(Math.abs(e) <= rawSum * 0.5 + 0.01, 
      `BUG-I: recovery ${meditation.tag} e=${e} exceeds 0.5×${rawSum}`);
  }
});

/* ─── GROUP 7: Fixed anchor behavior ──────────────────── */
t('anchor: future anchor placed at fixed time', () => {
  const r = analyze('샤워', {
    currentTime: '08:00',
    fixedEvents: [{ tag: 'regular_meeting', startAt: '10:00' }],
  });
  const anchor = r.schedule.timeline.find(s => s.tag === 'regular_meeting');
  assert(anchor, 'anchor not in timeline');
  assertEq(anchor.clockTime, '10:00');
  assertEq(anchor.isFixed, true);
});

t('BUG-C: past anchor is handled (not silently misplaced)', () => {
  const r = analyze('논문 쓰기', {
    currentTime: '14:00',
    fixedEvents: [{ tag: 'regular_meeting', startAt: '10:00' }],
  });
  const anchor = r.schedule.timeline.find(s => s.tag === 'regular_meeting');
  assert(!anchor, `BUG-C: past anchor should be dropped, found placed in timeline`);
  assert(Array.isArray(r.schedule.droppedAnchors), 'droppedAnchors array missing');
  const dropped = r.schedule.droppedAnchors.find(d => d.tag === 'regular_meeting');
  assert(dropped, 'past anchor not recorded in droppedAnchors');
  assert(['PAST_ANCHOR', 'STRICT_PAST'].includes(dropped.reason),
    `unexpected reason ${dropped.reason}`);
});

t('BUG-D: anchor interleave uses energy-adjusted time', () => {
  // Put a long flex activity before an anchor with tight buffer.
  // If interleaver used base time only, full_draft (360min × mult ≥ 1.0)
  // would still equal 360min base, not overflow. Need a case where
  // energy multiplier actually matters.
  // Use many prior activities to pump energy, then one near-fit activity.
  const r = analyze('운동하고 요리하고 저녁먹고 논문 읽고 회고', {
    currentTime: '08:00',
    fixedEvents: [{ tag: 'regular_meeting', startAt: '09:30' }],
  });
  // Find meeting in timeline
  const mtg = r.schedule.timeline.find(s => s.tag === 'regular_meeting');
  if (mtg) {
    assertEq(mtg.clockTime, '09:30', 'anchor should be at exact fixed time');
    // Any activity before the anchor must end at or before 09:30 (= 570)
    const before = r.schedule.timeline.filter(s =>
      !s.isGap && s.tag !== 'regular_meeting' &&
      s.startTime !== undefined && s.startTime < 570
    );
    for (const step of before) {
      const endTime = step.startTime + (step.actFinal || 0);
      assert(endTime <= 570 + 0.5,
        `BUG-D: ${step.tag} ends at ${endTime} past anchor at 570 (energy-unadjusted interleave)`);
    }
  }
});

t('BUG-H: P8 multiplier is actually applied to scheduled time', () => {
  // funeral (emo high) then cognitive task → P8 fires
  const r = analyze('장례 가고 논문 쓰기');
  const warning = r.emotionalWarnings?.find(w => w.multiplierSuggestion > 1.0);
  if (!warning) {
    // P8 didn't fire in this sequence — try a stronger test case
    return; // not a P8 scenario, skip
  }
  const affected = warning.affectedTag;
  const step = r.schedule.timeline.find(s => s.tag === affected);
  assert(step, `affected tag ${affected} not in timeline`);
  assert(step.p8MultiplierApplied === warning.multiplierSuggestion,
    `BUG-H: expected p8MultiplierApplied=${warning.multiplierSuggestion}, got ${step.p8MultiplierApplied}`);
  // Verify actFinal actually reflects the multiplier
  const expectedApprox = step.actAdjusted * step.energyMultiplier * warning.multiplierSuggestion;
  assert(Math.abs(step.actFinal - expectedApprox) / expectedApprox < 0.01,
    `BUG-H: actFinal=${step.actFinal} doesn't reflect ×${warning.multiplierSuggestion} multiplier (expected ~${expectedApprox})`);
});

/* ─── GROUP 9: Edge cases ─────────────────────────────── */
t('edge: empty input returns error gracefully', () => {
  const r = analyze('');
  assert(r.error);
});

t('edge: duplicate consecutive L3 collapsed', () => {
  const r = parseInput('운동하고 웨이트 트레이닝');
  // Current behavior: collapse. If this is intended, fine; if not, should emit two tags.
  // Lock current behavior as: ≤1 sports-strength activity.
  assert(r.tags.length <= 2);
});

t('edge: invalid fixedEvent tag does not crash', () => {
  const r = analyze('샤워', {
    currentTime: '08:00',
    fixedEvents: [{ tag: 'nonexistent_tag_xyz', startAt: '10:00' }],
  });
  assert(r.schedule, 'analyze crashed on invalid anchor');
});

/* ─── GROUP 10: Rule DSL integrity ────────────────────── */
import { DEP_RULES, validateRules, inferDependencyTyped, explainOrder } from './dep-rules.js';

t('DSL: all rule references resolve to valid taxonomy codes', () => {
  const issues = validateRules();
  assertEq(issues.length, 0, `invalid refs: ${JSON.stringify(issues)}`);
});

t('DSL: every rule has id, principle, when, strength', () => {
  for (const r of DEP_RULES) {
    assert(r.id, 'missing id');
    assert(r.principle, 'missing principle');
    assert(typeof r.when === 'function', 'when not a function');
    assert(['hard','soft'].includes(r.strength), `invalid strength ${r.strength} in ${r.id}`);
  }
});

t('DSL: inferDependency matches legacy on P1/P3/P10 cases', () => {
  const cases = [
    ['standard_meal', 'yogurt_granola', 'before', 'P1'],
    ['deadlift_session', 'full_shower', 'before', 'P3'],
    ['delicate_cycle', 'dryer_machine', 'before', 'P10'],
    ['dryer_machine', 'delicate_cycle', 'after', 'P10'],
  ];
  for (const [ta, tb, expected, expectP] of cases) {
    const a = getL4(ta), b = getL4(tb);
    if (!a || !b) continue;
    const r = inferDependencyTyped(a, b);
    assertEq(r.relation, expected, `${ta} vs ${tb}`);
    if (r.rule) assertEq(r.rule.principle, expectP);
  }
});

t('DSL: hard rules produce hard edges, soft rules produce soft edges', () => {
  // P3 is hard, P10.dry-before-fold is soft
  const r1 = inferDependencyTyped(getL4('deadlift_session'), getL4('full_shower'));
  assertEq(r1.strength, 'hard');
  const r2 = inferDependencyTyped(getL4('line_dry') || getL4('dryer_machine'),
                                  getL4('neat_fold') || getL4('quick_fold'));
  if (r2.rule) assertEq(r2.strength, 'soft');
});

t('BUG-E: gym triggers commute-like travel, not store travel', () => {
  const r = analyze('헬스장에서 운동');
  const travel = r.schedule.timeline.find(s => s.inferPrincip || s.tag.includes('drive_errand') || s.tag.includes('nearby_store'));
  // Find the outbound travel activity (inferred)
  const travelStep = r.schedule.timeline.find(s =>
    r.inferred.some(i => i.tag === s.tag && i.by?.includes('이동→활동'))
  );
  assert(travelStep, 'no outbound travel inferred');
  // Must not be a shopping-travel L4
  const l4 = getL4(travelStep.tag);
  assert(l4, `inferred tag ${travelStep.tag} not in L4_DB`);
  // For gym (l1=sports), mapping says 'drive_errand'
  assertEq(l4.l3, 'errand_trip',
    `BUG-E: sports destination should use errand_trip, got l3=${l4.l3}`);
});

t('BUG-E: office destination triggers commute travel', () => {
  const r = analyze('회사 가서 일하기');
  const travelStep = r.schedule.timeline.find(s =>
    r.inferred.some(i => i.tag === s.tag && i.by?.includes('이동→활동'))
  );
  if (travelStep) {
    const l4 = getL4(travelStep.tag);
    if (l4) {
      assert(l4.l3 === 'commute_to_work' || l4.l1 === 'traveling',
        `BUG-E: work destination travel l3=${l4.l3}`);
    }
  }
});

t('BUG-E: return trip uses different L4 for commute', () => {
  const r = analyze('회사 가서 일하기');
  // Outbound should differ from return
  const inferredTravelTags = r.inferred
    .filter(i => i.by?.includes('P4'))
    .map(i => i.tag);
  if (inferredTravelTags.length >= 2) {
    const [out, back] = inferredTravelTags;
    assert(out !== back,
      `BUG-E: outbound and return both ${out} — should differ for commute`);
  }
});

t('BUG-K: per-activity multiplier is bounded', () => {
  // Verify cap at PER_ACTIVITY_MULT_CAP regardless of cumulative energy
  const m1 = energyMultiplier(1000);  // absurdly high
  assert(m1 <= 1.51, `BUG-K: unbounded multiplier ${m1}`);
  const m2 = energyMultiplier(-1000); // absurdly low
  assert(m2 >= 0, `BUG-K: negative multiplier ${m2}`);
});

t('BUG-K: long activities do not explode under high energy', () => {
  // Run a sequence that builds high energy before a long activity
  const r = analyze('운동하고 요리하고 저녁먹고 논문 쓰기');
  const longStep = r.schedule.timeline.find(s => s.baseAct >= 100);
  if (longStep) {
    const ratio = longStep.actFinal / longStep.baseAct;
    assert(ratio <= 1.51, `BUG-K: ${longStep.tag} ballooned by ratio ${ratio}`);
  }
});

t('DSL: explainOrder gives human-readable trace', () => {
  const s = explainOrder(getL4('standard_meal'), getL4('yogurt_granola'));
  assert(s.includes('P1'), `expected P1 in: ${s}`);
});

/* ─── GROUP 11: Walker adversarial cases ──────────────── */

t('walker: anchor at exactly currentTime places immediately', () => {
  const r = analyze('샤워', {
    currentTime: '10:00',
    fixedEvents: [{ tag: 'regular_meeting', startAt: '10:00' }],
  });
  const nonGap = r.schedule.timeline.filter(s => !s.isGap);
  assertEq(nonGap[0].tag, 'regular_meeting');
  assertEq(nonGap[0].clockTime, '10:00');
});

t('walker: flex that doesnt fit before anchor waits out idle gap', () => {
  const r = analyze('논문 쓰기', {
    currentTime: '08:00',
    fixedEvents: [{ tag: 'regular_meeting', startAt: '09:30' }],
  });
  const gap = r.schedule.timeline.find(s => s.isGap);
  assert(gap, 'expected idle gap when flex doesnt fit');
  const mtg = r.schedule.timeline.find(s => s.tag === 'regular_meeting');
  const paper = r.schedule.timeline.find(s => s.tag === 'full_draft');
  assert(mtg && paper);
  assert(mtg.startTime < paper.startTime);
  assertEq(mtg.clockTime, '09:30');
});

t('walker: single source of truth — no timeline discontinuity', () => {
  const r = analyze('운동하고 요리하고 저녁 먹기', { currentTime: '06:00' });
  for (let i = 1; i < r.schedule.timeline.length; i++) {
    const cur = r.schedule.timeline[i];
    const prev = r.schedule.timeline[i - 1];
    if (cur.isGap || prev.isGap) continue;
    if (cur.inPassiveSlotOf) continue; // passive slot items nest
    assert(Math.abs(cur.startTime - prev.endTime) < 0.2,
      `step ${i} (${cur.tag}) starts at ${cur.startTime} but prev ${prev.tag} ended at ${prev.endTime}`);
  }
});

t('walker: droppedAnchors is always an array', () => {
  const r = analyze('샤워', { currentTime: '08:00' });
  assert(Array.isArray(r.schedule.droppedAnchors));
});

t('walker: past + future anchor — only future fires', () => {
  const r = analyze('샤워', {
    currentTime: '14:00',
    fixedEvents: [
      { tag: 'regular_meeting', startAt: '10:00' },   // L4 exists, past
      { tag: 'regular_meeting', startAt: '16:00' },   // same L4 (walker should still handle)
    ],
  });
  const pastDropped = r.schedule.droppedAnchors.filter(d =>
    d.reason === 'PAST_ANCHOR' || d.reason === 'STRICT_PAST');
  assertEq(pastDropped.length, 1, `expected 1 past anchor dropped, got ${pastDropped.length}`);
  const future = r.schedule.timeline.find(s => s.tag === 'regular_meeting');
  if (future) assertEq(future.clockTime, '16:00');
});

/* ─── GROUP 12: Task 1 — Time monotonicity (H1, H3, H4) ─ */
import { replan, filterExpiredAnchors } from './analyze-v3.js';
import { TimeContext, TimeRegressionError, parseTime } from './time-contract.js';

t('Task1/H1: clock clamps to now when clockStart < now', () => {
  // currentTime is 08:00 but we pass a TimeContext saying now=08:30.
  // The walker should start emitting at 08:30, not 08:00.
  const ctx = new TimeContext({ now: 8 * 60 + 30 });
  const r = analyze('샤워', { timeCtx: ctx });
  const first = r.schedule.timeline.find(s => !s.isGap);
  assertEq(first.clockTime, '08:30');
  assert(first.startTime >= ctx.now - 0.1, `H1 violated: ${first.startTime} < ${ctx.now}`);
});

t('Task1/H4: replan with earlier now throws TimeRegressionError', () => {
  const r1 = analyze('샤워', { now: '09:00' });
  let caught = null;
  try {
    replan(r1, '08:30');
  } catch (e) { caught = e; }
  assert(caught instanceof TimeRegressionError,
    `expected TimeRegressionError, got ${caught?.constructor?.name}`);
  assertEq(caught.kind, 'NOW_WENT_BACKWARD');
});

t('Task1/H4: replan with same now succeeds (equality allowed)', () => {
  const r1 = analyze('샤워', { now: '09:00' });
  const r2 = replan(r1, '09:00');
  assert(r2.ctx);
  assertEq(r2.ctx.now, 9 * 60);
  assertEq(r2.ctx.epoch, 1);
});

t('Task1/H4: replan advances epoch', () => {
  const r1 = analyze('샤워', { now: '09:00' });
  const r2 = replan(r1, '09:30');
  const r3 = replan(r2, '10:00');
  assertEq(r1.ctx.epoch, 0);
  assertEq(r2.ctx.epoch, 1);
  assertEq(r3.ctx.epoch, 2);
});

t('Task1/FP-2: replan without prev ctx throws', () => {
  let caught = null;
  try { replan({}, '09:00'); } catch (e) { caught = e; }
  assert(caught instanceof TimeRegressionError);
  assertEq(caught.kind, 'REPLAN_REQUIRES_CTX');
});

t('Task1/H1: every step in timeline has startTime ≥ now', () => {
  const ctx = new TimeContext({ now: 10 * 60 });
  const r = analyze('샤워하고 아침 먹고 운동', { timeCtx: ctx });
  for (const step of r.schedule.timeline) {
    if (step.isGap) continue;
    assert(step.startTime >= ctx.now - 0.1,
      `H1 violated on ${step.tag}: startTime=${step.startTime} < now=${ctx.now}`);
  }
});

t('Task1: past anchor threshold uses ctx.now, not clockStart', () => {
  // Construct pathological case: clockStart would allow 09:00 anchor (clockStart=08:00),
  // but ctx.now is 09:30 — anchor must still be rejected.
  const ctx = new TimeContext({ now: 9 * 60 + 30 });
  const r = analyze('샤워', {
    timeCtx: ctx,
    fixedEvents: [{ tag: 'regular_meeting', startAt: '09:00' }],
  });
  const dropped = r.schedule.droppedAnchors.find(d => d.tag === 'regular_meeting');
  assert(dropped, 'past anchor should be dropped based on ctx.now');
});

t('Task1: invalid time format throws typed error', () => {
  let caught = null;
  try { parseTime('9am'); } catch (e) { caught = e; }
  assert(caught instanceof TimeRegressionError);
  assertEq(caught.kind, 'INVALID_TIME_FORMAT');
});

t('Task1: negative now throws', () => {
  let caught = null;
  try { new TimeContext({ now: -1 }); } catch (e) { caught = e; }
  assert(caught instanceof TimeRegressionError);
  assertEq(caught.kind, 'INVALID_NOW');
});

/* ─── GROUP 13: Task 2 — Expired anchor handling ─ */

t('Task2: STRICT_PAST anchors filtered at pre-filter', () => {
  const ctx = new TimeContext({ now: 14 * 60 });
  const { kept, dropped } = filterExpiredAnchors(
    [{ tag: 'x', startAt: '10:00' }, { tag: 'y', startAt: '15:00' }],
    ctx, {}
  );
  assertEq(kept.length, 1);
  assertEq(kept[0].tag, 'y');
  assertEq(dropped.length, 1);
  assertEq(dropped[0].reason, 'STRICT_PAST');
});

t('Task2: OVERLAPPED_BY_RUNNING — anchor inside running task window', () => {
  const ctx = new TimeContext({ now: 10 * 60 });
  // Running task from 10:00 to 10:45. Anchor at 10:30 must be dropped.
  const { kept, dropped } = filterExpiredAnchors(
    [{ tag: 'x', startAt: '10:30' }, { tag: 'y', startAt: '11:00' }],
    ctx, { runningTask: { id: 'foo', endsAt: 10 * 60 + 45 } }
  );
  assertEq(kept.length, 1);
  assertEq(kept[0].tag, 'y');
  const over = dropped.find(d => d.reason === 'OVERLAPPED_BY_RUNNING');
  assert(over, 'expected OVERLAPPED_BY_RUNNING entry');
  assertEq(over.tag, 'x');
});

t('Task2: COLLAPSED_AFTER_DELAY — same-minute duplicate', () => {
  const ctx = new TimeContext({ now: 8 * 60 });
  const { kept, dropped } = filterExpiredAnchors(
    [
      { tag: 'meeting_a', startAt: '10:00' },
      { tag: 'meeting_b', startAt: '10:00' },  // collides
    ],
    ctx, {}
  );
  assertEq(kept.length, 1);
  assertEq(kept[0].tag, 'meeting_a');
  const coll = dropped.find(d => d.reason === 'COLLAPSED_AFTER_DELAY');
  assert(coll, 'expected COLLAPSED_AFTER_DELAY entry');
});

t('Task2: no ctx → no filtering (backward compat)', () => {
  const { kept, dropped } = filterExpiredAnchors(
    [{ tag: 'x', startAt: '10:00' }], null, {}
  );
  assertEq(kept.length, 1);
  assertEq(dropped.length, 0);
});

/* ─── GROUP 14: Task 3 — Interruption handling ─ */
import { makeInterrupted, buildResumeItems, interruptedEnergyContribution } from './interruption.js';

t('Task3: makeInterrupted records elapsed and remaining (resume)', () => {
  const intr = makeInterrupted({
    itemId: 'full_shower', originalAct: 12,
    startedAt: 8 * 60, pausedAt: 8 * 60 + 5,
    resumeMode: 'resume',
  });
  assertEq(intr.elapsed, 5);
  assertEq(intr.remaining, 7);
  assertEq(intr.state, 'Paused');
});

t('Task3: restart mode resets remaining to originalAct', () => {
  const intr = makeInterrupted({
    itemId: 'full_shower', originalAct: 12,
    startedAt: 8 * 60, pausedAt: 8 * 60 + 5,
    resumeMode: 'restart',
  });
  assertEq(intr.remaining, 12);
  assertEq(intr.energyFraction, 0);
});

t('Task3: abandon mode → remaining = 0, state = Abandoned', () => {
  const intr = makeInterrupted({
    itemId: 'full_shower', originalAct: 12,
    startedAt: 8 * 60, pausedAt: 8 * 60 + 5,
    resumeMode: 'abandon',
  });
  assertEq(intr.remaining, 0);
  assertEq(intr.state, 'Abandoned');
});

t('Task3/INT-1: negative elapsed throws', () => {
  let caught = null;
  try {
    makeInterrupted({
      itemId: 'full_shower', originalAct: 12,
      startedAt: 8 * 60 + 5, pausedAt: 8 * 60,  // paused BEFORE started
      resumeMode: 'resume',
    });
  } catch (e) { caught = e; }
  assert(caught instanceof TimeRegressionError);
  assertEq(caught.kind, 'INTERRUPT_NEGATIVE_ELAPSED');
});

t('Task3: elapsed clamped to originalAct (over-run case)', () => {
  const intr = makeInterrupted({
    itemId: 'full_shower', originalAct: 10,
    startedAt: 8 * 60, pausedAt: 8 * 60 + 20,  // ran over
    resumeMode: 'resume',
  });
  assertEq(intr.elapsed, 10);
  assertEq(intr.remaining, 0);
});

t('Task3/INT-6: abandoned tasks do not appear in buildResumeItems', () => {
  const items = buildResumeItems([
    makeInterrupted({
      itemId: 'full_shower', originalAct: 12,
      startedAt: 8 * 60, pausedAt: 8 * 60 + 5,
      resumeMode: 'abandon',
    }),
  ]);
  assertEq(items.length, 0);
});

t('Task3: resume item has act = remaining, not originalAct', () => {
  const items = buildResumeItems([
    makeInterrupted({
      itemId: 'full_shower', originalAct: 12,
      startedAt: 8 * 60, pausedAt: 8 * 60 + 5,
      resumeMode: 'resume',
    }),
  ]);
  assertEq(items.length, 1);
  assertEq(items[0].act, 7);
  assert(items[0]._interrupted, 'expected _interrupted metadata');
});

t('Task3/INT-4: resume energy contribution = fraction * base', () => {
  // Item with baseline 10, elapsed half → only 5 of energy remains to accumulate.
  const item = {
    tag: 'x', phy: 2, cog: 2, emo: 0, l1: '_', l2: '_', l3: '_',
    _interrupted: { mode: 'resume', energyFraction: 0.5 },
  };
  // baseEnergy would be 4 (+ cross-fatigue), but we're testing the function's shape.
  const result = interruptedEnergyContribution(item, 10);
  assertEq(result, 5);
});

t('Task3/INT-5: restart energy contribution = full base', () => {
  const item = {
    tag: 'x', _interrupted: { mode: 'restart', energyFraction: 0 },
  };
  const result = interruptedEnergyContribution(item, 10);
  assertEq(result, 10);
});

t('Task3/INT-3: resumed task placed with startTime ≥ now (H1)', () => {
  // Interrupted shower, remaining 7 min, resume at 08:30.
  const intr = makeInterrupted({
    itemId: 'full_shower', originalAct: 12,
    startedAt: 8 * 60, pausedAt: 8 * 60 + 5,
    resumeMode: 'resume',
  });
  const ctx = new TimeContext({ now: 8 * 60 + 30 });
  const r = analyze('샤워', {
    timeCtx: ctx,
    interruptions: [intr],
  });
  const shower = r.schedule.timeline.find(s => s.tag === 'full_shower');
  assert(shower, 'shower should be in timeline');
  assert(shower.startTime >= ctx.now - 0.1, `INT-3: ${shower.startTime} < ${ctx.now}`);
  // Duration should be 7 (remaining), not 12 (original)
  assert(shower.baseAct === 7 || Math.abs(shower.actFinal - 7) < 1,
    `expected ~7 min, got baseAct=${shower.baseAct} actFinal=${shower.actFinal}`);
});

t('Task3: resumed task does not duplicate if also in parsed input', () => {
  // User input has "샤워", and we pass an interruption for full_shower.
  // Should result in ONE shower entry (the resumed one).
  const intr = makeInterrupted({
    itemId: 'full_shower', originalAct: 12,
    startedAt: 8 * 60, pausedAt: 8 * 60 + 5,
    resumeMode: 'resume',
  });
  const ctx = new TimeContext({ now: 8 * 60 + 30 });
  const r = analyze('샤워', { timeCtx: ctx, interruptions: [intr] });
  const showerCount = r.schedule.timeline.filter(s => s.tag === 'full_shower').length;
  assertEq(showerCount, 1, `expected exactly 1 shower, got ${showerCount}`);
});

/* ─── GROUP 15: Task 4 — Slack-based control ─ */
import { CONFIG } from './scheduler.js';

t('Task4: admits flex when predTotal ≤ effectiveSlack', () => {
  // shower=12min, anchor at 08:30 from 08:00 → slack=30, effective=24, 12 ≤ 24 → admit
  const r = analyze('샤워', {
    now: '08:00',
    fixedEvents: [{ tag: 'regular_meeting', startAt: '08:30' }],
  });
  const shower = r.schedule.timeline.find(s => s.tag === 'full_shower');
  const mtg = r.schedule.timeline.find(s => s.tag === 'regular_meeting');
  assert(shower && mtg);
  assert(shower.startTime < mtg.startTime, 'shower should precede meeting');
});

t('Task4: rejects flex when predTotal > effectiveSlack (safety margin engaged)', () => {
  // shower=12min, slack=13 → effective=10.4, 12>10.4 → reject, jump to anchor
  const r = analyze('샤워', {
    now: '08:00',
    fixedEvents: [{ tag: 'regular_meeting', startAt: '08:13' }],
  });
  const mtg = r.schedule.timeline.find(s => s.tag === 'regular_meeting');
  const shower = r.schedule.timeline.find(s => s.tag === 'full_shower');
  assertEq(mtg.clockTime, '08:13');
  // Shower should have been deferred — emitted AFTER anchor, not before
  assert(shower.startTime >= mtg.startTime + mtg.actFinal - 0.1,
    `shower ${shower.startTime} should start at/after anchor end ${mtg.startTime + mtg.actFinal}`);
  // Observability: anchor step records the rejection
  assert(mtg.slackRejection, 'expected slackRejection metadata on anchor step');
  assertEq(mtg.slackRejection.deferredTag, 'full_shower');
  assertEq(mtg.slackRejection.reason, 'REJECT_EXCEEDS');
});

t('Task4: safety margin is 0.8 (spec §Safety Margin)', () => {
  assertEq(CONFIG.SLACK_SAFETY_MARGIN, 0.8);
});

t('Task4: passive time is included in predTotal', () => {
  // washing_machine has pas > 0. Slack must be large enough for act + pas, not just act.
  // delicate_cycle: act=5, pas varies. With tight slack, passive-bearing item must defer.
  const r = analyze('빨래', {
    now: '08:00',
    fixedEvents: [{ tag: 'regular_meeting', startAt: '08:10' }],  // 10 min slack
  });
  // delicate_cycle act=5 but pas typically 45+ → predTotal >> effective slack (8) → reject
  const wash = r.schedule.timeline.find(s => s.tag === 'delicate_cycle');
  const mtg = r.schedule.timeline.find(s => s.tag === 'regular_meeting');
  if (wash && mtg) {
    assert(wash.startTime >= mtg.startTime + mtg.actFinal - 0.1,
      `Task4 passive inclusion: wash should be deferred, got start=${wash.startTime} vs anchor_end=${mtg.startTime + mtg.actFinal}`);
  }
});

t('Task4: NEAR_ZERO_SLACK rejects even zero-cost items', () => {
  // Anchor at 08:00 exactly, currentTime 08:00 → slack=0 → case A fires, not gate.
  // Test gate path: slack ≤ EPS but > 0.
  const r = analyze('샤워', {
    now: '08:00',
    fixedEvents: [{ tag: 'regular_meeting', startAt: '08:00' }],
  });
  // Meeting fires first (case A), shower comes after
  const nonGap = r.schedule.timeline.filter(s => !s.isGap);
  assertEq(nonGap[0].tag, 'regular_meeting');
});

t('Task4: multi-anchor — nearest FUTURE anchor is used for slack', () => {
  // Two anchors ahead: 08:13 and 09:00. Shower=12 must reject (slack vs nearest=13,
  // effective=10.4, 12>10.4 → defer). After anchor1 fires, re-evaluate against anchor2.
  const r = analyze('샤워', {
    now: '08:00',
    fixedEvents: [
      { tag: 'regular_meeting', startAt: '08:13' },
      { tag: 'regular_meeting', startAt: '09:00' },
    ],
  });
  const meetings = r.schedule.timeline.filter(s => s.tag === 'regular_meeting');
  assertEq(meetings.length, 2, `expected 2 meetings, got ${meetings.length}`);
  assertEq(meetings[0].clockTime, '08:13');
  assertEq(meetings[1].clockTime, '09:00');
  // First anchor rejected shower; second anchor should show the shower fits (between 08:13+45=08:58 and 09:00, slack ~2min → still rejects, so shower after 09:00)
  const shower = r.schedule.timeline.find(s => s.tag === 'full_shower');
  assert(shower, 'shower emitted somewhere');
});

t('Task4: deferred flex eventually emits (no silent drop)', () => {
  // Shower rejected against tight anchor, should still appear in final timeline after anchor.
  const r = analyze('샤워', {
    now: '08:00',
    fixedEvents: [{ tag: 'regular_meeting', startAt: '08:13' }],
  });
  const shower = r.schedule.timeline.find(s => s.tag === 'full_shower');
  assert(shower, 'deferred shower must still appear in timeline');
});

t('Task4: large task vs tight slack — jump-to-anchor policy', () => {
  // full_draft=360min, slack=60 → effective=48, 360>>48 → reject, fire anchor, defer paper
  const r = analyze('논문 쓰기', {
    now: '08:00',
    fixedEvents: [{ tag: 'regular_meeting', startAt: '09:00' }],
  });
  const nonGap = r.schedule.timeline.filter(s => !s.isGap);
  // Order must be: [idle_gap?], meeting, paper
  const mtgIdx = nonGap.findIndex(s => s.tag === 'regular_meeting');
  const paperIdx = nonGap.findIndex(s => s.tag === 'full_draft');
  assert(mtgIdx < paperIdx, 'meeting must precede paper under slack policy');
});

t('Task4: no anchor → gate always admits (unconstrained path)', () => {
  const r = analyze('샤워하고 아침 먹기', { now: '08:00' });
  // All user items emit — no rejections
  assert(r.schedule.timeline.length >= 2);
  for (const step of r.schedule.timeline) {
    if (step.isGap) continue;
    assert(!step.slackRejection, `unexpected rejection on ${step.tag}`);
  }
});

t('Task4: relative-time mode (no ctx) bypasses slack gate', () => {
  const r = analyze('샤워');  // no now, no currentTime
  const shower = r.schedule.timeline.find(s => s.tag === 'full_shower');
  assert(shower);
});

/* ─── GROUP 16: Problems 1/2/3 — Stabilization proofs ─ */

t('P1: effClock never yields a past value — H1 holds at every emission', () => {
  // Construct a ctx that's ahead of clockStart; verify every emission has startTime ≥ now.
  const ctx = new TimeContext({ now: 9 * 60 });
  const r = analyze('샤워하고 아침 먹고 운동', { timeCtx: ctx });
  for (const step of r.schedule.timeline) {
    if (step.isGap || step.isReserve) continue;
    assert(step.startTime >= ctx.now - 0.2,
      `P1 violated: ${step.tag} start=${step.startTime} < now=${ctx.now}`);
  }
});

t('P1: anchor placed inside the (old_clockStart, ctx.now) window fires exactly once without inflation', () => {
  // clockStart=08:00 (from currentTime), ctx.now=09:00, anchor at 09:15.
  // Pre-fix: slack could be read as 09:15 - 08:00 = 75min → flex admits when it shouldn't.
  // Post-fix: slack = 09:15 - 09:00 = 15min, effective=12min, shower(12)=12 → EPS-admit.
  const ctx = new TimeContext({ now: 9 * 60 });
  const r = analyze('샤워', {
    timeCtx: ctx,
    fixedEvents: [{ tag: 'regular_meeting', startAt: '09:15' }],
  });
  const shower = r.schedule.timeline.find(s => s.tag === 'full_shower');
  const mtg = r.schedule.timeline.find(s => s.tag === 'regular_meeting');
  assert(shower, 'shower emitted');
  assert(mtg, 'meeting placed');
  assertEq(mtg.clockTime, '09:15');
  // shower cannot start before 09:00
  assert(shower.startTime >= 9 * 60 - 0.2, `shower.startTime=${shower.startTime}`);
  // and must end by meeting start (within float tolerance)
  const end = shower.startTime + shower.actFinal;
  assert(end <= 9 * 60 + 15 + 0.2, `shower overflows anchor: end=${end}`);
});

t('P1: without the fix, stale clockStart would inflate slack — now it does not', () => {
  // Worst-case: currentTime="08:00" (clockStart=480) but ctx.now=530 (08:50).
  // Anchor at 09:00 (540). Slack MUST be measured as 540-530=10, NOT 540-480=60.
  // With 10min slack, shower(12min) cannot fit → must defer.
  const ctx = new TimeContext({ now: 8 * 60 + 50 });
  const r = analyze('샤워', {
    currentTime: '08:00',   // stale; should be overridden by ctx
    timeCtx: ctx,
    fixedEvents: [{ tag: 'regular_meeting', startAt: '09:00' }],
  });
  const mtg = r.schedule.timeline.find(s => s.tag === 'regular_meeting');
  const shower = r.schedule.timeline.find(s => s.tag === 'full_shower');
  assert(mtg && shower);
  // Shower should be deferred past the meeting
  assert(shower.startTime >= mtg.startTime + mtg.actFinal - 0.2,
    `slack inflation bug: shower@${shower.startTime} before/inside meeting ending @${mtg.startTime + mtg.actFinal}`);
});

t('P2: determinism — same input yields same timeline (no ordering bias)', () => {
  const r1 = analyze('샤워하고 아침 먹고 운동', { now: '08:00' });
  const r2 = analyze('샤워하고 아침 먹고 운동', { now: '08:00' });
  assertDeepEq(
    r1.schedule.timeline.map(s => ({ tag: s.tag, start: s.startTime, end: s.endTime })),
    r2.schedule.timeline.map(s => ({ tag: s.tag, start: s.startTime, end: s.endTime })),
    'schedules differ between identical runs'
  );
});

t('P2: passive slot — planning state is NOT leaked into real cumulative energy', () => {
  // After a passive-slot host with candidates filled, finalEnergy should equal
  // baseline + host.contrib + sum of admitted-candidate contribs (NO planning leak).
  const r = analyze('빨래하고 설거지하고 방청소하고 책읽기', { now: '08:00' });
  const hostStep = r.schedule.timeline.find(s => s.passiveSlot && s.passiveSlot.filled.length > 0);
  if (hostStep) {
    // Snapshot metadata exists
    assert(hostStep.passiveSlot.baseEnergySnapshot !== undefined,
      'baseEnergySnapshot missing — PHASE 1 snapshot not recorded');
    assert(hostStep.passiveSlot.baseClockSnapshot !== undefined,
      'baseClockSnapshot missing');
  }
});

t('P2: evaluateCandidate is pure — repeated calls with same snapshot yield same result', () => {
  // Indirect test: call analyze twice with identical inputs, the internal state is
  // reset each time, so determinism from P2 test is the covering proof. This test
  // adds an explicit seam: invoke analyze twice back-to-back on the SAME module and
  // verify finalEnergy is bit-identical (not just close).
  const r1 = analyze('운동하고 요리하고 저녁먹고 논문 쓰기', { now: '06:00' });
  const r2 = analyze('운동하고 요리하고 저녁먹고 논문 쓰기', { now: '06:00' });
  assertEq(r1.schedule.finalEnergy, r2.schedule.finalEnergy);
  assertEq(r1.schedule.totalActive, r2.schedule.totalActive);
});

t('P3: EPS tolerance — boundary at effectiveSlack + 0.05 admits', () => {
  // Construct a case where predTotal is within EPS of effectiveSlack.
  // effectiveSlack = slack × 0.8. slack=15 → eff=12. Shower=12min → exactly fits.
  const r = analyze('샤워', {
    now: '08:00',
    fixedEvents: [{ tag: 'regular_meeting', startAt: '08:15' }],
  });
  const shower = r.schedule.timeline.find(s => s.tag === 'full_shower');
  const mtg = r.schedule.timeline.find(s => s.tag === 'regular_meeting');
  assert(shower, 'boundary case: shower should admit within EPS');
  assert(shower.startTime < mtg.startTime, 'shower should precede meeting');
});

t('P3: EPS does not widen capacity — predTotal > effectiveSlack + EPS rejects', () => {
  // slack=13 → effective=10.4 → EPS-adjusted ceiling=10.5. Shower(12) > 10.5 → reject.
  const r = analyze('샤워', {
    now: '08:00',
    fixedEvents: [{ tag: 'regular_meeting', startAt: '08:13' }],
  });
  const mtg = r.schedule.timeline.find(s => s.tag === 'regular_meeting');
  const shower = r.schedule.timeline.find(s => s.tag === 'full_shower');
  assert(shower.startTime >= mtg.startTime + mtg.actFinal - 0.2,
    'shower should be deferred — EPS must not allow >EPS overrun');
  assert(mtg.slackRejection);
  assertEq(mtg.slackRejection.reason, 'REJECT_EXCEEDS');
});

t('P3: near-zero slack → reserve slot emitted + anchor fires + flex deferred', () => {
  // Slack = 0.3 min (below RESERVE_THRESHOLD=0.5). parseTime accepts numeric input,
  // so we bypass the HH:MM regex to construct a fractional anchor.
  const r = analyze('샤워', {
    now: 480,                                            // 08:00
    fixedEvents: [{ tag: 'regular_meeting', startAt: 480.3 }],  // 08:00.3
  });
  const reserves = r.schedule.timeline.filter(s => s.isReserve);
  assertEq(reserves.length, 1, 'expected exactly 1 reserve slot');
  const res = reserves[0];
  // Spec §Reserve Slot Semantics — all required fields present and inert
  assertEq(res.type, 'padding');
  assertEq(res.energy, 0);
  assertEq(res.decisionWeight, 0);
  assertEq(res.visibleOnly, true);
  assertEq(res.actFinal, 0);
  assertEq(res.pasFinal, 0);
  assertEq(res.reserveReason, 'NEAR_ZERO_SLACK');
  assert(res.durationGap > 0 && res.durationGap <= 0.5);
  // Anchor fires next; shower deferred to AFTER the anchor
  const mtg = r.schedule.timeline.find(s => s.tag === 'regular_meeting');
  const shower = r.schedule.timeline.find(s => s.tag === 'full_shower');
  assertEq(mtg.startTime, 480.3);
  assert(shower.startTime > mtg.startTime, 'shower must defer past anchor');
});

t('P3: slack just above threshold (0.6) → idle gap, NOT reserve', () => {
  // Confirms the branch distinction: only slack ≤ 0.5 triggers reserve.
  const r = analyze('샤워', {
    now: 480,
    fixedEvents: [{ tag: 'regular_meeting', startAt: 480.6 }],
  });
  const reserves = r.schedule.timeline.filter(s => s.isReserve);
  const gaps = r.schedule.timeline.filter(s => s.isGap && !s.isReserve);
  assertEq(reserves.length, 0, 'slack > threshold should NOT produce reserve');
  assert(gaps.length >= 1, 'expected idle_gap since shower(12) > effective slack(0.48)');
});

t('P3: reserve slot does not contribute energy or decision weight', () => {
  const r = analyze('샤워하고 아침 먹기', {
    now: 480,
    fixedEvents: [{ tag: 'regular_meeting', startAt: 480.4 }],
  });
  const reserves = r.schedule.timeline.filter(s => s.isReserve);
  // Sum of energy across all reserves must be 0
  const totalReserveEnergy = reserves.reduce((s, r) => s + (r.energy || 0), 0);
  assertEq(totalReserveEnergy, 0);
  // finalEnergy must match what it would be WITHOUT the reserve in the mix
  // (we can't easily compare to a "no reserve" run, but we can assert monotonic
  //  non-negative energy trace)
  for (const e of r.schedule.energyTrace) {
    assert(typeof e.cumulative === 'number', 'energyTrace entry missing cumulative');
  }
});

t('P3: reserve slot preserves clock monotonicity — next step starts at reserve end', () => {
  const r = analyze('샤워', {
    now: 480,
    fixedEvents: [{ tag: 'regular_meeting', startAt: 480.3 }],
  });
  const res = r.schedule.timeline.find(s => s.isReserve);
  const mtg = r.schedule.timeline.find(s => s.tag === 'regular_meeting');
  assertEq(res.endTime, mtg.startTime, 'reserve must end exactly at next step start');
});

t('P3: predictable dispatch — no post-hoc overflow correction', () => {
  // Property: if slackGate admits, the emission must fit. If it rejects, the
  // anchor fires in the same iteration. There is no timeConflict=true path
  // that is merely LABELED — if it appears, it means a fix escaped, which is
  // itself a regression.
  const r = analyze('샤워하고 아침 먹고 운동', {
    now: '08:00',
    fixedEvents: [{ tag: 'regular_meeting', startAt: '08:20' }],
  });
  const conflicts = r.schedule.timeline.filter(s => s.timeConflict);
  assertEq(conflicts.length, 0,
    `timeConflict steps should be impossible post-stabilization, got ${conflicts.length}`);
});

t('P3: formatSchedule does not crash on reserve slots (regression)', () => {
  // Latent bug caught during P3 integration: formatSchedule assumed every non-gap
  // step has energyMultiplier. Reserve slots don't. Verify output is well-formed.
  const r = analyze('샤워', {
    now: 480,
    fixedEvents: [{ tag: 'regular_meeting', startAt: 480.3 }],
  });
  assert(typeof r.summary === 'string');
  assert(r.summary.includes('reserve'), 'summary should mention reserve slot');
  // No undefined.toFixed crashes — if we got here, formatSchedule survived.
});

console.log(`\n${'='.repeat(50)}\n${passed} passed, ${failed} failed\n${'='.repeat(50)}`);
if (failed > 0) {
  console.log('\nFAILURES:');
  for (const f of failures) console.log(`  ${f.name}: ${f.error}`);
  process.exit(1);
}
